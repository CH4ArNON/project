import UIKit

var a1 = 5
var a2 = 4
var sum = a1+a2
var dif = a1-a2
var mul = a1*a2
var div = a1/a2
print("summary = ",sum)
print("different = ",dif)
print("multiply = ",mul)
print("divide = ",div)
